#include "mydate.h"

myDate::myDate()
{

}
