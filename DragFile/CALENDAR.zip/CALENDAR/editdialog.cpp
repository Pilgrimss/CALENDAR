#include "editdialog.h"

editDialog::editDialog()
{

}
