#ifndef MYDATE_H
#define MYDATE_H

#include <QObject>
#include <QWidget>
#include <QDate>
class myDate : public QDate
{
public:
    myDate();
};

#endif // MYDATE_H
