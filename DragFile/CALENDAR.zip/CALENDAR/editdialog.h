#ifndef EDITDIALOG_H
#define EDITDIALOG_H

#include <QObject>
#include <QWidget>

class editDialog : public noteDialog
{
public:
    editDialog();
};

#endif // EDITDIALOG_H