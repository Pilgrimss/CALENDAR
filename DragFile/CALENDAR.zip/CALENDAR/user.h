#ifndef USER_H
#define USER_H


class user
{
public:
    user();
private:

};

#endif // USER_H
